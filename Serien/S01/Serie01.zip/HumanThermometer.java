//Lukas Batschelet, 16-499-733
package serie01;

import java.util.Scanner;

public class HumanThermometer {
    public static void main(String[] args) {
		final int LOWER_BOUND = 15;
		final int UPPER_BOUND = 24;
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Die aktuelle Temperatur: ");
		int temperature = scan.nextInt();
		
		if (temperature < LOWER_BOUND) {
			System.out.println("Es ist kalt");
		} 
		else if ((LOWER_BOUND <= temperature) && (temperature <= UPPER_BOUND)) {
			System.out.println("Es ist angenehm");
		} 
		else
			System.out.println("Es ist warm");
		
		scan.close();
	}
}
