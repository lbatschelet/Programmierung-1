//Lukas Batschelet, 16-499-733
package serie01;

import java.util.Scanner;

public class Quotient {
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("Geben Sie den Teil \"a\" ein:");
        double var1 = scan.nextDouble();
        
        System.out.println("Geben Sie den Teil \"b\" ein:");
        double var2 = scan.nextDouble();
        
        if (var2 != 0) { //Wert 0 führt zu divide by zero
            double quotientDouble = (var1 * var1) / var2;
            int quotientInt = ((int) var1 * (int) var1) / (int) var2;
            System.out.println("________________________________________________________________________\n" + 
                "Der Quotient Ihrer Zahlen: \t" + quotientDouble + 
                "\nUnd als \"int\":\t \t \t" + quotientInt);
        } else { 
            System.out.println("Geben Sie nicht 0 ein!");
        }

        scan.close();
    }
}
