//Lukas Batschelet, 16-499-733
package serie01;

public class WinterIsComing {
    public static void main(String[] args) {
		System.out.println("\"Winter is coming\"");
		System.out.println("\"Winter \n" +
				"is \n" +
				"coming\"");
	}
}
